﻿using ReactiveUI;
using System;
using System.Collections.Generic;
using System.Text;

namespace IoTPi.ViewModels
{
    public class ProcessedViewModel : ViewModelBase
    {
        internal static ProcessedViewModel Instance;

        public ProcessedViewModel()
        {
            Instance = this;
        }

        public void ReceiveData(string data)
        {
            TemperatureArea0 = data;
        }

        #region TemperatureArea0 
        private string temperaturearea0;
        public string TemperatureArea0
        {
            get => temperaturearea0;
            set => this.RaiseAndSetIfChanged(ref temperaturearea0, value);
          
        }
        #endregion
    }
}
