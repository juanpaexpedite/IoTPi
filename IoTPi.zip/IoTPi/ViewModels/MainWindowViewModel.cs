﻿using Avalonia.Threading;
using System;
using System.Collections.Generic;
using System.Text;

namespace IoTPi.ViewModels
{
    public class MainWindowViewModel : ViewModelBase
    {
        public string Greeting => "Welcome to Avalonia!";

        public MainWindowViewModel()
        {
            Processed = new ProcessedViewModel();

            var timer = new DispatcherTimer();
            timer.Tick += Timer_Tick;
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            Random rnd = new Random();
            Processed.ReceiveData($"{rnd.Next(25, 30)} C");
        }

        public ProcessedViewModel Processed { get; }
    }
}
