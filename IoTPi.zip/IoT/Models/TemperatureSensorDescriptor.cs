﻿using ReactiveUI;
using System;
using System.Collections.Generic;
using System.Text;

namespace IoT.Models
{
    public class TemperatureSensorDescriptor : ReactiveObject
    {
        private string id;
        public string Id
        {
            get => id;
            set => this.RaiseAndSetIfChanged(ref id, value);
        }

        private double dvalue;
        public double Value
        {
            get => dvalue;
            set => this.RaiseAndSetIfChanged(ref dvalue, value);
        }

        private string description;
        public string Description
        {
            get => description;
            set => this.RaiseAndSetIfChanged(ref description, value);
        }

        private DateTime timestamp;
        public DateTime TimeStamp
        {
            get => timestamp;
            set => this.RaiseAndSetIfChanged(ref timestamp, value);
        }
    }
}
